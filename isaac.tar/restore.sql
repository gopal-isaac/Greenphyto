--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "GreenphytoDB";
--
-- Name: GreenphytoDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "GreenphytoDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en-SG';


ALTER DATABASE "GreenphytoDB" OWNER TO postgres;

\connect "GreenphytoDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: plantconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plantconfiguration (
    tray_id integer NOT NULL,
    plant_type text NOT NULL,
    target_temperature numeric NOT NULL,
    target_humidity numeric NOT NULL,
    target_light integer NOT NULL
);


ALTER TABLE public.plantconfiguration OWNER TO postgres;

--
-- Name: sensorreading; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensorreading (
    id integer NOT NULL,
    tray_id integer NOT NULL,
    temperature numeric NOT NULL,
    humidity numeric NOT NULL,
    light integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sensorreading OWNER TO postgres;

--
-- Name: sensorreading_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sensorreading_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sensorreading_id_seq OWNER TO postgres;

--
-- Name: sensorreading_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sensorreading_id_seq OWNED BY public.sensorreading.id;


--
-- Name: sensorreading id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensorreading ALTER COLUMN id SET DEFAULT nextval('public.sensorreading_id_seq'::regclass);


--
-- Data for Name: plantconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plantconfiguration (tray_id, plant_type, target_temperature, target_humidity, target_light) FROM stdin;
\.
COPY public.plantconfiguration (tray_id, plant_type, target_temperature, target_humidity, target_light) FROM '$$PATH$$/4898.dat';

--
-- Data for Name: sensorreading; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sensorreading (id, tray_id, temperature, humidity, light, created_at) FROM stdin;
\.
COPY public.sensorreading (id, tray_id, temperature, humidity, light, created_at) FROM '$$PATH$$/4900.dat';

--
-- Name: sensorreading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sensorreading_id_seq', 27, true);


--
-- Name: plantconfiguration plantconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantconfiguration
    ADD CONSTRAINT plantconfiguration_pkey PRIMARY KEY (tray_id);


--
-- Name: sensorreading sensorreading_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensorreading
    ADD CONSTRAINT sensorreading_pkey PRIMARY KEY (id);


--
-- Name: sensorreading sensorreading_tray_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensorreading
    ADD CONSTRAINT sensorreading_tray_id_fkey FOREIGN KEY (tray_id) REFERENCES public.plantconfiguration(tray_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

